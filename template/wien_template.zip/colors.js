const COLORS = {
    buslines: {
        "Blue Line": "#0074D9",
        "Green Line": "#2ECC40",
        "Grey Line": "#AAAAAA",
        "Orange Line": "#FF851B",
        "Red Line": "#FF4136",
        "Yellow Line": "#FFDC00"
    }
};